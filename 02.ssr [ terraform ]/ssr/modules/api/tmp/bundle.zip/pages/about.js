const About = () => {
  return (
    <div>
      <h1>
        About NextJS
              </h1>
      <p>Application to Demonstrate NextJS Basics</p>
    </div>
  )
}

export default About
