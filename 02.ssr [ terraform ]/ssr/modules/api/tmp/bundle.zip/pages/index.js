const Index = () => {
  return (
    <div>
      <h1>Welcome to Next Application</h1>
    </div>
  )
}
export default Index
