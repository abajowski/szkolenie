  
#!/bin/sh

npm install
npm build
npm prune --production
